﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        ListBox1 = New ListBox()
        Label2 = New Label()
        ListBox2 = New ListBox()
        Label3 = New Label()
        ListBox3 = New ListBox()
        Label4 = New Label()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(12, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(187, 25)
        Label1.TabIndex = 0
        Label1.Text = "TVL-ICT(2024-2025)"
        ' 
        ' ListBox1
        ' 
        ListBox1.FormattingEnabled = True
        ListBox1.ItemHeight = 15
        ListBox1.Items.AddRange(New Object() {"BOYS", "", "00931 - ACON, NADHER D.", "01405 - ANA, SEBASTIAN LOUIS L.", "00914 - ANTANAO, FRANCIS E.", "00938 - ANTELINO, JOMER B.", "00971 - APOSTOL, JAY-R FRANCIS L.", "00858 - ARTILLO, RONIE S.", "00071 - BARBA, KAIZER BENEDICT A.", "01480 - BARREDO, JOHN ANDREI H.", "00930 - BARRIENTOS, SHANE N.", "01389 - BATISTIS, JOHN LAUREN L.", "01538 - BERON, JOERHIN PAUL C.", "00669 - BOEY, KEANU D.", "00226 - BOLLENA, KEITH BRYAN M.", "01531 - BOOL, DUSTIN KIM M.", "01537 - BORJA JR., JOSEPH B.", "00215 - BOTON, BON OLIVER E.", "01399 - BUENA, LEI AIVERSON S.", "00913 - CABRERA, JOHN PAUL C.", "00211 - CALZADO, JOHN CLAUDE", "01371 - CASTRO, JOHNN LHEENARD", "00970 - CIONELO, JOSHUA CLARENCE D.G.", "00428 - CORDERO, JOSHUA D.", "00610 - CRUZ, MARION ELVIN C.", "00987 - CRUZ, MARK GENESIS V.", "00072 - CRUZ, LORENZO ANTONIO F.", "01046 - DALAGON, ALEX JAY P.", "00989 - DE GUZMAN, JAMES ALDRIN L.", "00127 - DEGUZMAN, SAMUEL R.", "00968 - DELA RAMA, STEVEN J.", "01563 - SAGABAY, REC GABRIEL YZHEN C.", "01550 - SANTOS, REIGN YLLOR M.", "01545 - VANZUELA, JYLE JOSEPH V.", "", "GIRLS", "", "01559 - ABELLA, JENNUEL ANN G.", "00985 - CAPISTRANO, JANESSA J.", "00979 - CASCAÑO, SHANELLA LAURIZE E.", "00927 - CRUZ, JUNE ABEGAIL M.", "00421 - DAEL, HALLE MAE O."})
        ListBox1.Location = New Point(12, 100)
        ListBox1.Name = "ListBox1"
        ListBox1.Size = New Size(697, 139)
        ListBox1.TabIndex = 1
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(12, 82)
        Label2.Name = "Label2"
        Label2.Size = New Size(81, 15)
        Label2.TabIndex = 2
        Label2.Text = "ICT-BABBAGE"
        ' 
        ' ListBox2
        ' 
        ListBox2.FormattingEnabled = True
        ListBox2.ItemHeight = 15
        ListBox2.Items.AddRange(New Object() {"BOYS", "", "01554 - DEGUZMAN, JOMUEL E.", "01555 - DELA CRUZ, MICCO ANGELO P.", "00406 - DELOS SANTOS III, BENJAMIN D. ", "01233 - ENRIQUEZ, REI TH YANCY P. ", "00055 - ESPIRITU, BRENT ASHLEY O", "00912 - ESPOSO, EDSEL B.", "01570 - FELIX, CRAIG CYRUS P.", "01373 - FRANCISCO, CHARLES BRAIN J. ", "01544 - FRANCO, FRANCIZ ANGELO N.", "00126 - GABASA, CLARCK EDWARD JOHN G.", "00177 - GUIVARRA, JOHN LAURENCE N. ", "01424 - JACINTO, ALDRIN M.", "01556 - JAVIER, CARL BENEDICT J", "01205 - LARA, PATRICK JOHN A.", "00904 - MAGULYAN, CLARENCE E.", "00917 - MAGSAEL, RON ALFHIE  00918  MAMARIL, VINCENT A. ", "01501 - MANICANE, LEANDER ANDREI S.  ", "01511 - MARASIGAN, RAINDEL LUIS ZENON M. ", "00976 - MARCELO, NIXON O.", "00338 - MATIC, CHARLES KEVIN A.", "00929 - MONTESENES, JOHN RAY F. ", "", " GIRLS", "", "00519 - DIAMADA, JISELEY C. ", "00992 - DOMINGO, RHIAN LESI C.", "00936 - ESTANISLAO, LESBELLE MAE V. ", "00983 - FERRER, HANNAH JEAN J. ", "00963 - FOLLERO, KUMI V.- 00963  ", "01132 - FORMALEJO, MARIEL ANN S.", "00933 - GALICIA, ASHLEY JOY YURI P.", "01385 - GALIDO, ALYSSA CAMILLE S. ", "00999 - GUARDA, JESSIE LOREN F. ", "00668 - GUINAREZ, ALYSSA N.", "00424 - HOPIO, IRISH APPLE D.", "01241 - LORENZO, RUTH MAE A.", "01558 - MACASINAG, EISSEN J.", "00194 - MARVIL, ROSE MARIE L. ", "00115 - MEDALLA, JASME NARRA M. ", "00926 - MEDIAVILLO, NISHA PAULA P."})
        ListBox2.Location = New Point(12, 285)
        ListBox2.Name = "ListBox2"
        ListBox2.Size = New Size(697, 139)
        ListBox2.TabIndex = 3
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(12, 267)
        Label3.Name = "Label3"
        Label3.Size = New Size(98, 15)
        Label3.TabIndex = 4
        Label3.Text = "ICT-THOMPSON"
        ' 
        ' ListBox3
        ' 
        ListBox3.FormattingEnabled = True
        ListBox3.ItemHeight = 15
        ListBox3.Items.AddRange(New Object() {"BOYS", "", "00995 - MUÑOZ, DREW JEREMIE S.", "01047 - NATINO, KIMELLE MOOR D.", "00912 - NEPANGUE, KURT DUSTINE M.", "00797 - OMAÑA, KEN JHORDAN T.", "01504 - ONGJOCO, DAN MITCHELL A.", "01053 - PAITAN, RAVEN JAMES P.", "01054 - PANAGUITON, RAFFY G.", "00249 - PAREÑAS, CLARK JASON M.", "01354 - POLISON, REYLAND C.", "01209 - RAMIREZ, JAMES KARL B.", "00832 - RAMOS, SHIAN JEREMIAH G.", "01481 - ROAMAR, JOHN EARL R.", "01481 - RUELO, JAMES M.", "00928 - SABADO, JAN MARK V.", "00642 - SAN JOSE, JAEHRON MICHAEL S.", "00515 - SOLIVO, JOFE JAMES A.", "00994 - STA ISABEL, MEDRIC J.", "00937 - SUNGA, STANLEY HANS T.", "01311 - TENOSO, RECSIE MARK M.", "00210 - TIMBAL, MADDYSON JOHN P.", "00632 - TOLANG, RENZ MARK G.", "00212 - TOLEDO, ALEZI C.", "00964 - TORRES, ZACHARY G.", "01420 - TORREVILLAS, CATALINO D.", "01246 - TROYO, CHRISTIAN JAMES B.", "01206 - TUNGCUL, JANSEN N.", "01026 - UY, LANCE ADRIANE", "00972 - VILLA, MACKIE", "00701 - VILLAPAZ, JORDAN C.", "01502 - VILLENA, LAURENCE S.", "01022 - YUSON, ANTONIO JOSEPH A.", "", "GIRLS", "", "00960 - RANCES, PAMELA JOY A.", "00517 - SAN DIEGO, LEA MARGARETH P.", "00738 - SANTOS, HANNA MARIE D.", "00980 - SOLIMAN, HANNAH C.", "01348 - TAN, JAMAICA MAE A.", "01522 - TOMAS, RHIAN SHANE"})
        ListBox3.Location = New Point(12, 461)
        ListBox3.Name = "ListBox3"
        ListBox3.Size = New Size(697, 139)
        ListBox3.TabIndex = 5
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(12, 443)
        Label4.Name = "Label4"
        Label4.Size = New Size(75, 15)
        Label4.TabIndex = 6
        Label4.Text = "ICT-COOPER"
        ' 
        ' Form6
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(955, 594)
        Controls.Add(Label4)
        Controls.Add(ListBox3)
        Controls.Add(Label3)
        Controls.Add(ListBox2)
        Controls.Add(Label2)
        Controls.Add(ListBox1)
        Controls.Add(Label1)
        Name = "Form6"
        Text = "Form6"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Label2 As Label
    Friend WithEvents ListBox2 As ListBox
    Friend WithEvents Label3 As Label
    Friend WithEvents ListBox3 As ListBox
    Friend WithEvents Label4 As Label
End Class
